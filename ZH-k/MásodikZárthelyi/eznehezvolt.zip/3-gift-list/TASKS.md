# Task 3

- [x] a.
- [x] b.
- [x] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
